import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

function TelaNovoProduto() {
  // PASSO 3: Estados para valores e erros
  const [nome, setNome] = useState('');
  const [preco, setPreco] = useState('');
  const [descricao, setDescricao] = useState('');
  
  const [erroNome, setErroNome] = useState('');
  const [erroPreco, setErroPreco] = useState('');

  // PASSO 4: Lógica de Validação
  const validarESalvar = () => {
    let valido = true;

    // Validação do Nome
    if (nome.trim().length < 3) {
      setErroNome('O nome deve ter pelo menos 3 letras');
      valido = false;
    } else {
      setErroNome('');
    }

    // Validação do Preço
    const precoNum = parseFloat(preco);
    if (!preco || precoNum <= 0) {
      setErroPreco('O preço deve ser um número maior que zero');
      valido = false;
    } else {
      setErroPreco('');
    }

    // PASSO 6: Sucesso
    if (valido) {
      Alert.alert('Sucesso', 'Produto cadastrado com sucesso!');
      setNome('');
      setPreco('');
      setDescricao('');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Campo Nome */}
      <Text style={styles.label}>Nome do Produto</Text>
      <TextInput
        style={[styles.input, erroNome ? styles.inputErro : null]} // PASSO 5: Borda vermelha
        value={nome}
        onChangeText={setNome}
        placeholder="Ex: Teclado Mecânico"
      />
      {erroNome ? <Text style={styles.textoErro}>{erroNome}</Text> : null}

      {/* Campo Preço */}
      <Text style={styles.label}>Preço (R$)</Text>
      <TextInput
        style={[styles.input, erroPreco ? styles.inputErro : null]}
        value={preco}
        onChangeText={setPreco}
        placeholder="0.00"
        keyboardType="numeric" // PASSO 2: Teclado numérico
      />
      {erroPreco ? <Text style={styles.textoErro}>{erroPreco}</Text> : null}

      {/* Campo Descrição */}
      <Text style={styles.label}>Descrição (Opcional)</Text>
      <TextInput
        style={[styles.input, styles.inputArea]}
        value={descricao}
        onChangeText={setDescricao}
        placeholder="Detalhes do produto..."
        multiline={true} // PASSO 2: Multiline
        numberOfLines={4}
      />

      <TouchableOpacity style={styles.botao} onPress={validarESalvar}>
        <Text style={styles.botaoTexto}>Cadastrar Produto</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#2196F3' }, headerTintColor: '#fff' }}>
        <Stack.Screen name="NovoProduto" component={TelaNovoProduto} options={{ title: 'Cadastro de Produto' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: '#fff' },
  label: { fontSize: 16, fontWeight: 'bold', marginBottom: 5, color: '#333' },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 12, fontSize: 16, marginBottom: 5 },
  inputArea: { height: 100, textAlignVertical: 'top' },
  inputErro: { borderColor: '#f44336', borderWidth: 2 }, // PASSO 5: Estilo de erro
  textoErro: { color: '#f44336', fontSize: 12, marginBottom: 15, fontWeight: '500' },
  botao: { backgroundColor: '#2196F3', padding: 15, borderRadius: 8, alignItems: 'center', marginTop: 20 },
  botaoTexto: { color: '#fff', fontSize: 18, fontWeight: 'bold' }
});