import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';

function ListaCompras() {
  const [item, setItem] = useState('');
  const [lista, setLista] = useState([]);

  // PASSO 6: Carregar lista ao abrir o app
  useEffect(() => {
    async function carregarDados() {
      const dados = await AsyncStorage.getItem('@minha_lista');
      if (dados) setLista(JSON.parse(dados));
    }
    carregarDados();
  }, []);

  // PASSO 3: Salvar lista (Sempre que a lista mudar)
  const salvarLista = async (novaLista) => {
    setLista(novaLista);
    await AsyncStorage.setItem('@minha_lista', JSON.stringify(novaLista));
  };

  // PASSO 2: Adicionar item
  const adicionarItem = () => {
    if (item.trim() === '') return;
    const novaLista = [...lista, { id: Date.now().toString(), nome: item }];
    salvarLista(novaLista);
    setItem('');
  };

  // PASSO 5: Remover item
  const removerItem = (id) => {
    const novaLista = lista.filter(item => item.id !== id);
    salvarLista(novaLista);
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputArea}>
        <TextInput
          style={styles.input}
          placeholder="Ex: Maçã"
          value={item}
          onChangeText={setItem}
        />
        <TouchableOpacity style={styles.botaoAdd} onPress={adicionarItem}>
          <Ionicons name="add" size={30} color="white" />
        </TouchableOpacity>
      </View>

      {/* PASSO 4: Renderizar com FlatList */}
      <FlatList
        data={lista}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemLista}>
            <Text style={styles.itemTexto}>{item.nome}</Text>
            <TouchableOpacity onPress={() => removerItem(item.id)}>
              <Ionicons name="trash-outline" size={24} color="#ff5252" />
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#4caf50' }, headerTintColor: '#fff' }}>
        <Stack.Screen name="ListaCompras" component={ListaCompras} options={{ title: 'Minha Lista' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f9f9f9' },
  inputArea: { flexDirection: 'row', marginBottom: 20 },
  input: { flex: 1, borderBottomWidth: 1, borderColor: '#ccc', marginRight: 10, padding: 8, fontSize: 18 },
  botaoAdd: { backgroundColor: '#4caf50', borderRadius: 5, padding: 5, justifyContent: 'center' },
  itemLista: { flexDirection: 'row', backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 10, justifyContent: 'space-between', elevation: 2 },
  itemTexto: { fontSize: 18 }
});