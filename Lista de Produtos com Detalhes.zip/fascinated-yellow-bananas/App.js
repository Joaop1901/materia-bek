import * as React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// PASSO 2: Tela com a lista de botões
function ListaProdutos({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.tituloPrincipal}>Escolha um Produto:</Text>
      
      {/* PASSO 3: Navegando e passando o objeto como parâmetro */}
      <View style={styles.buttonSpacing}>
        <Button 
          title="Ver Notebook" 
          onPress={() => navigation.navigate('Detalhes', { nome: 'Notebook Ultra Slim', preco: 'R$ 3.499,00' })} 
        />
      </View>
      <View style={styles.buttonSpacing}>
        <Button 
          title="Ver Smartphone" 
          onPress={() => navigation.navigate('Detalhes', { nome: 'Smartphone G54', preco: 'R$ 1.899,00' })} 
        />
      </View>
      <View style={styles.buttonSpacing}>
        <Button 
          title="Ver Fone" 
          onPress={() => navigation.navigate('Detalhes', { nome: 'Fone Noise Cancelling', preco: 'R$ 599,00' })} 
        />
      </View>
    </View>
  );
}

// PASSO 4 & 5: Tela que recebe e exibe os dados
function DetalhesProduto({ route }) {
  const { nome, preco } = route.params; // Capturando os dados enviados

  return (
    <View style={styles.container}>
      <Text style={styles.nomeProduto}>{nome}</Text>
      <Text style={styles.precoProduto}>{preco}</Text>
    </View>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator 
        screenOptions={{
          headerStyle: { backgroundColor: '#2196F3' },
          headerTintColor: '#fff',
        }}
      >
        <Stack.Screen name="Lista" component={ListaProdutos} options={{ title: 'Loja Tech' }} />
        
        {/* PASSO 6: Alterando o título do cabeçalho para 'Informações' */}
        <Stack.Screen 
          name="Detalhes" 
          component={DetalhesProduto} 
          options={{ title: 'Informações' }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  tituloPrincipal: { fontSize: 20, marginBottom: 20, color: '#333' },
  buttonSpacing: { marginBottom: 15, width: '80%' },
  nomeProduto: { fontSize: 28, fontWeight: 'bold', color: '#000', marginBottom: 10 },
  precoProduto: { fontSize: 22, color: '#2196F3', fontWeight: '600' }
});