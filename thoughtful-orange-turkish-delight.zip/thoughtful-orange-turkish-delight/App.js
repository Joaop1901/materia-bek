import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import { Card } from 'react-native-paper';

// 🔴 Filho SEM memo (sempre re-renderiza)
const FilhoLento = () => {
  console.log('🔴 FilhoLento renderizou');
  return <Text style={styles.box}>Filho Lento</Text>;
};

// 🟢 Filho COM memo (evita re-render)
const FilhoRapido = React.memo(() => {
  console.log('🟢 FilhoRapido renderizou');
  return <Text style={styles.box}>Filho Rápido</Text>;
});

export default function App() {
  const [contador, setContador] = useState(0);

  return (
    <View style={styles.container}>
      <Card style={styles.card}>
        <Text style={styles.title}>Renderizações</Text>

        <Text style={styles.counter}>
          {contador} re-renders
        </Text>

        <View style={styles.resultBox}>
          <Text style={{ color: 'green', fontWeight: 'bold' }}>
            Com React.memo: 1 re-render
          </Text>
        </View>

        <FilhoLento />
        <FilhoRapido />

        <View style={styles.buttons}>
          <TouchableOpacity
            style={styles.btnRed}
            onPress={() => setContador(contador + 1)}
          >
            <Text style={styles.btnText}>Sem memo</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.btnGreen}
            onPress={() => setContador(contador + 1)}
          >
            <Text style={styles.btnText}>Com memo</Text>
          </TouchableOpacity>
        </View>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 16,
  },
  card: {
    padding: 20,
    borderRadius: 10,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  counter: {
    fontSize: 28,
    color: 'red',
    marginBottom: 15,
  },
  resultBox: {
    backgroundColor: '#d4f5d4',
    padding: 10,
    borderRadius: 8,
    marginBottom: 15,
  },
  box: {
    marginVertical: 5,
    fontSize: 16,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  btnRed: {
    backgroundColor: '#e74c3c',
    padding: 10,
    borderRadius: 8,
  },
  btnGreen: {
    backgroundColor: '#2ecc71',
    padding: 10,
    borderRadius: 8,
  },
  btnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});