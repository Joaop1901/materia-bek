import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage'; // PASSO 3

function TelaPerfil() {
  const [nome, setNome] = useState('');
  const [nomeSalvo, setNomeSalvo] = useState('');

  // PASSO 4: Carregar o dado ao abrir o App
  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      const valor = await AsyncStorage.getItem('@meu_nome');
      if (valor !== null) {
        setNomeSalvo(valor);
      }
    } catch (e) {
      console.log("Erro ao carregar", e);
    }
  };

  // PASSO 3: Salvar o dado
  const salvar = async () => {
    try {
      await AsyncStorage.setItem('@meu_nome', nome);
      setNomeSalvo(nome);
      setNome('');
      Alert.alert('Sucesso', 'Nome salvo localmente!');
    } catch (e) {
      console.log("Erro ao salvar", e);
    }
  };

  // PASSO 5: Apagar o dado
  const apagar = async () => {
    try {
      await AsyncStorage.removeItem('@meu_nome');
      setNomeSalvo('');
      Alert.alert('Limpo', 'Nome removido do armazenamento.');
    } catch (e) {
      console.log("Erro ao apagar", e);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
        {nomeSalvo ? `Bem-vindo de volta, ${nomeSalvo}!` : 'Qual é o seu nome?'}
      </Text>

      {/* PASSO 2: Input e Botões */}
      <TextInput
        style={styles.input}
        placeholder="Digite seu nome aqui..."
        value={nome}
        onChangeText={setNome}
      />

      <View style={styles.row}>
        <Button title="Salvar" onPress={salvar} color="#2196F3" />
        <View style={{ width: 10 }} />
        <Button title="Apagar" onPress={apagar} color="#f44336" />
      </View>
      
      <Text style={styles.footer}>Os dados persistem após o recarregamento.</Text>
    </View>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Perfil" component={TelaPerfil} options={{ title: 'Meu Perfil' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20, backgroundColor: '#fff' },
  titulo: { fontSize: 22, fontWeight: 'bold', marginBottom: 20, textAlign: 'center' },
  input: { borderBottomWidth: 1, borderColor: '#ccc', width: '100%', marginBottom: 20, padding: 8, fontSize: 18 },
  row: { flexDirection: 'row' },
  footer: { marginTop: 30, fontSize: 12, color: 'gray' }
});